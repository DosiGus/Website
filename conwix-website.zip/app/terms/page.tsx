export default function TermsPage() {
  return (
    <section className="mx-auto max-w-3xl px-4 py-16 prose prose-slate">
      <h1>Terms of Service (Placeholder)</h1>
      <p>These are placeholder terms. Replace with your actual terms before going live.</p>
      <h2>Use of Service</h2>
      <p>By using this website you agree to the final terms once published.</p>
    </section>
  )
}
