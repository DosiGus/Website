export default function PrivacyPage() {
  return (
    <section className="mx-auto max-w-3xl px-4 py-16 prose prose-slate">
      <h1>Privacy Policy (Placeholder)</h1>
      <p>This is a placeholder privacy policy. Replace with your actual privacy statement appropriate for your jurisdiction (e.g., GDPR).</p>
      <h2>Data We Collect</h2>
      <p>Contact form inputs (name, email, message) and basic visitor analytics if enabled.</p>
      <h2>Contact</h2>
      <p>For privacy inquiries, contact: privacy@example.com</p>
    </section>
  )
}
