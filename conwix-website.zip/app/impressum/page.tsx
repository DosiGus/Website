export default function ImpressumPage() {
  return (
    <section className="mx-auto max-w-3xl px-4 py-16 prose prose-slate">
      <h1>Impressum (Placeholder)</h1>
      <p>This is placeholder legal information for Germany. Replace with your actual company details.</p>
      <ul>
        <li>Company Name: Placeholder GmbH</li>
        <li>Address: Sample Street 1, 00000 City, Country</li>
        <li>Represented by: Placeholder Person</li>
        <li>Contact: hello@example.com</li>
        <li>VAT ID: DE000000000</li>
      </ul>
      <h2>Disclaimer</h2>
      <p>Content on this website is placeholder. Replace with your own legal text.</p>
    </section>
  )
}
